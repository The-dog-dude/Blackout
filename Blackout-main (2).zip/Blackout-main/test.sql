CREATE TABLE users (
    username TEXT,
    password TEXT
);

INSERT INTO users (username, password) VALUES ('Jeff', 'tunaguy');
INSERT INTO users (username, password) VALUES ('Bob', 'swordfish');
